# Fulfillment-Pulsa Databricks bundle

Reconstructed from screenshots of the working `Fulfillment_Pulsa_Pipeline` job (job ID `810985515038426`).

## Before deploying

1. Place `databricks.yml` in the repository root, and `fulfillment_job.yml` inside `resources/`.
2. Confirm the notebook files are in the repository root, with exact names:
   - `fulfilment_pulsa_bronze_and_silver.ipynb`
   - `fulfillment_gold.ipynb`
   - `04_Gold_to_fabric.ipynb`
3. The screenshot job used **Git provider (main)**. This bundle instead deploys local Git-tracked notebooks to the workspace. This is intentional: the bundle keeps notebook source under Git but avoids a second job-level Git checkout. It is not a byte-for-byte export of the existing job.
4. Recreate the catalog, schema, source volume, CSVs, tables, and secret scope `fulfilment-fabric` before running. Keep secret values out of Git.
5. Confirm the target Fabric Lakehouse and Entra service principal still exist.
6. Update the workspace URL when recreating Databricks.

## CLI commands

Authenticate:

```powershell
databricks auth login --host https://YOUR-WORKSPACE.azuredatabricks.net
```

Validate and deploy (from the repository root):

```powershell
databricks bundle validate --var 'workspace_host=https://YOUR-WORKSPACE.azuredatabricks.net'
databricks bundle deploy --var 'workspace_host=https://YOUR-WORKSPACE.azuredatabricks.net'
```

To run (billable compute):

```powershell
databricks bundle run fulfillment_pulsa_pipeline --var 'workspace_host=https://YOUR-WORKSPACE.azuredatabricks.net'
```

## Notes

- The job has three tasks, sequential dependencies, serverless compute and no schedule.
- Environment version `6` is copied from screenshots. The three Python packages are added based on the Fabric publishing notebook, not verified against the existing job's environment settings. Pin versions later if necessary.
- The bundle does **not** automatically import or take over the existing UI-created job. A deployment normally creates a separate bundle-managed job; avoid running duplicates.
- Verify the notebook paths and package compatibility with your current Databricks CLI/runtime before deployment. This configuration has not been live-validated.
- If you want an exact job backup, also export `databricks jobs get 810985515038426 --output json` before deleting the workspace.
